# tickets/views.py
from django.shortcuts import render, get_object_or_404, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q, Count
from django.core.paginator import Paginator
from django.http import JsonResponse
from django.core.mail import send_mail
from django.conf import settings
from django.contrib.admin.views.decorators import staff_member_required
from .models import Ticket, TicketComment, TicketVote, Category, TicketAttachment
from .forms import TicketCreateForm, CommentForm, TicketFilterForm, TicketUpdateForm, CategoryForm
from django.contrib.auth import get_user_model

User = get_user_model()


def home_view(request):
    """
    Home page view for the QuickDesk application
    """
    if request.user.is_authenticated:
        return redirect('dashboard')
    
    context = {
        'title': 'Welcome to QuickDesk',
    }
    return render(request, 'tickets/home.html', context)


@login_required
def dashboard_view(request):
    # Different dashboard for agents vs regular users
    is_agent = request.user.groups.filter(name='Agents').exists()
    
    if is_agent:
        # For agents, show all tickets
        tickets = Ticket.objects.all()
        stats = {
            'total_tickets': tickets.count(),
            'open_tickets': tickets.filter(status='open').count(),
            'pending_tickets': tickets.filter(status='in_progress').count(),
            'resolved_tickets': tickets.filter(status__in=['resolved', 'closed']).count(),
        }
        
        # Show tickets assigned to this agent and recent unassigned tickets
        assigned_tickets = tickets.filter(assigned_to=request.user).order_by('-updated_at')[:5]
        unassigned_tickets = tickets.filter(assigned_to=None).order_by('-created_at')[:5]
        
        context = {
            'stats': stats,
            'recent_tickets': assigned_tickets,
            'unassigned_tickets': unassigned_tickets,
            'is_agent': True,
        }
    else:
        # For regular users, show only their tickets
        user_tickets = Ticket.objects.filter(created_by=request.user)
        stats = {
            'total_tickets': user_tickets.count(),
            'open_tickets': user_tickets.filter(status='open').count(),
            'pending_tickets': user_tickets.filter(status='in_progress').count(),
            'resolved_tickets': user_tickets.filter(status__in=['resolved', 'closed']).count(),
        }
        recent_tickets = user_tickets.order_by('-updated_at')[:5]

        context = {
            'stats': stats,
            'recent_tickets': recent_tickets,
            'is_agent': False,
        }
    
    return render(request, 'tickets/dashboard.html', context)


@login_required
def ticket_list_view(request):
    form = TicketFilterForm(request.GET)
    tickets = Ticket.objects.all()

    if not request.user.groups.filter(name='Agents').exists():
        tickets = tickets.filter(created_by=request.user)

    if form.is_valid():
        search = form.cleaned_data.get('search')
        status = form.cleaned_data.get('status')
        category = form.cleaned_data.get('category')
        priority = form.cleaned_data.get('priority')
        sort_by = form.cleaned_data.get('sort_by')

        if search:
            tickets = tickets.filter(
                Q(subject__icontains=search) |
                Q(description__icontains=search) |
                Q(id__icontains=search)
            )

        if status:
            tickets = tickets.filter(status=status)

        if category:
            tickets = tickets.filter(category=category)

        if priority:
            tickets = tickets.filter(priority=priority)

        tickets = tickets.annotate(comments_count=Count('comments'))

        if sort_by:
            if sort_by == 'comments_count':
                tickets = tickets.order_by('-comments_count', '-updated_at')
            elif sort_by == 'upvotes':
                tickets = tickets.order_by('-upvotes', '-updated_at')
            else:
                tickets = tickets.order_by(f'-{sort_by}')

    paginator = Paginator(tickets, 10)
    page_number = request.GET.get('page')
    page_obj = paginator.get_page(page_number)

    context = {
        'page_obj': page_obj,
        'form': form,
    }
    return render(request, 'tickets/ticket_list.html', context)


@login_required
def ticket_create_view(request):
    if request.method == 'POST':
        form = TicketCreateForm(request.POST)
        files = request.FILES.getlist('attachments')

        if form.is_valid():
            ticket = form.save(commit=False)
            ticket.created_by = request.user
            ticket.save()

            for file in files:
                TicketAttachment.objects.create(
                    ticket=ticket,
                    file=file,
                    filename=file.name,
                    uploaded_by=request.user
                )

            send_ticket_notification(ticket, 'created')

            messages.success(request, f'Ticket {ticket.id} created successfully!')
            return redirect('ticket_detail', pk=ticket.pk)
    else:
        form = TicketCreateForm()

    return render(request, 'tickets/ticket_create.html', {'form': form})


@login_required
def ticket_detail_view(request, pk):
    ticket = get_object_or_404(Ticket, pk=pk)

    if not request.user.groups.filter(name='Agents').exists() and ticket.created_by != request.user:
        messages.error(request, 'You can only view your own tickets.')
        return redirect('ticket_list')

    if request.method == 'POST':
        comment_form = CommentForm(request.POST)
        if comment_form.is_valid():
            comment = comment_form.save(commit=False)
            comment.ticket = ticket
            comment.author = request.user
            comment.save()

            ticket.save()
            send_ticket_notification(ticket, 'comment_added')

            messages.success(request, 'Comment added successfully!')
            return redirect('ticket_detail', pk=ticket.pk)
    else:
        comment_form = CommentForm()

    update_form = None
    if request.user.groups.filter(name='Agents').exists():
        update_form = TicketUpdateForm(instance=ticket)

    context = {
        'ticket': ticket,
        'comment_form': comment_form,
        'update_form': update_form,
    }
    return render(request, 'tickets/ticket_detail.html', context)


@login_required
def ticket_update_view(request, pk):
    ticket = get_object_or_404(Ticket, pk=pk)

    if not request.user.groups.filter(name='Agents').exists():
        messages.error(request, 'You do not have permission to update tickets.')
        return redirect('ticket_detail', pk=ticket.pk)

    if request.method == 'POST':
        form = TicketUpdateForm(request.POST, instance=ticket)
        if form.is_valid():
            old_status = ticket.status
            ticket = form.save()

            if old_status != ticket.status:
                send_ticket_notification(ticket, 'status_changed')

            messages.success(request, 'Ticket updated successfully!')
            return redirect('ticket_detail', pk=ticket.pk)

    return redirect('ticket_detail', pk=ticket.pk)


@login_required
def vote_ticket(request, pk):
    if request.method == 'POST':
        ticket = get_object_or_404(Ticket, pk=pk)
        vote_type = request.POST.get('vote_type')

        if vote_type in ['up', 'down']:
            vote, created = TicketVote.objects.get_or_create(
                ticket=ticket,
                user=request.user,
                defaults={'vote_type': vote_type}
            )

            if not created:
                if vote.vote_type != vote_type:
                    vote.vote_type = vote_type
                    vote.save()
                else:
                    vote.delete()

            upvotes = ticket.votes.filter(vote_type='up').count()
            downvotes = ticket.votes.filter(vote_type='down').count()

            ticket.upvotes = upvotes
            ticket.downvotes = downvotes
            ticket.save()

            return JsonResponse({
                'success': True,
                'upvotes': upvotes,
                'downvotes': downvotes
            })

    return JsonResponse({'success': False})


@staff_member_required
def category_list_view(request):
    categories = Category.objects.all()
    return render(request, 'tickets/category_list.html', {'categories': categories})


@staff_member_required
def category_create_view(request):
    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Category created successfully!')
            return redirect('category_list')
    else:
        form = CategoryForm()
    
    return render(request, 'tickets/category_form.html', {'form': form, 'title': 'Create Category'})


@staff_member_required
def category_update_view(request, pk):
    category = get_object_or_404(Category, pk=pk)
    
    if request.method == 'POST':
        form = CategoryForm(request.POST, instance=category)
        if form.is_valid():
            form.save()
            messages.success(request, 'Category updated successfully!')
            return redirect('category_list')
    else:
        form = CategoryForm(instance=category)
    
    return render(request, 'tickets/category_form.html', {'form': form, 'title': 'Update Category'})


@staff_member_required
def category_delete_view(request, pk):
    category = get_object_or_404(Category, pk=pk)
    
    if request.method == 'POST':
        # Check if there are tickets using this category
        if category.tickets.exists():
            messages.error(request, 'Cannot delete category that has tickets assigned to it.')
            return redirect('category_list')
        
        category.delete()
        messages.success(request, 'Category deleted successfully!')
        return redirect('category_list')
    
    return render(request, 'tickets/category_confirm_delete.html', {'category': category})


def send_ticket_notification(ticket, action):
    if action == 'created':
        subject = f'New Ticket Created: {ticket.id}'
        message = f'A new ticket has been created:\n\nSubject: {ticket.subject}\nDescription: {ticket.description}\n\nView ticket: {ticket.get_absolute_url()}'
        # Only send to agents who have enabled this notification
        recipient_list = [user.email for user in User.objects.filter(groups__name='Agents', notify_ticket_created=True) if user.email]

    elif action == 'updated':
        subject = f'Ticket Updated: {ticket.id}'
        message = f'Ticket {ticket.id} has been updated.\n\nSubject: {ticket.subject}\n\nView ticket: {ticket.get_absolute_url()}'
        # Only send to ticket creator if they have enabled this notification
        if ticket.created_by.email and ticket.created_by.notify_ticket_updated:
            recipient_list = [ticket.created_by.email]
        else:
            recipient_list = []

    elif action == 'status_changed':
        subject = f'Ticket Status Changed: {ticket.id}'
        message = f'Ticket {ticket.id} status has been changed to {ticket.get_status_display()}.\n\nSubject: {ticket.subject}\n\nView ticket: {ticket.get_absolute_url()}'
        # Only send to ticket creator if they have enabled this notification
        if ticket.created_by.email and ticket.created_by.notify_ticket_status_changed:
            recipient_list = [ticket.created_by.email]
        else:
            recipient_list = []
    
    elif action == 'comment_added':
        subject = f'New Comment on Ticket: {ticket.id}'
        message = f'A new comment has been added to ticket {ticket.id}.\n\nSubject: {ticket.subject}\n\nView ticket: {ticket.get_absolute_url()}'
        # Only send to ticket creator if they have enabled this notification
        if ticket.created_by.email and ticket.created_by.notify_ticket_comment:
            recipient_list = [ticket.created_by.email]
        else:
            recipient_list = []

    if recipient_list:
        try:
            send_mail(
                subject,
                message,
                settings.EMAIL_HOST_USER,
                recipient_list,
                fail_silently=True,
            )
        except Exception as e:
            print(f"Failed to send email: {e}")
